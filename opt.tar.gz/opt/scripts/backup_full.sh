#!/bin/bash

#Funcion de ayuda
mostrar_ayuda() {
	echo "Uso: $0 <origen> <destino>"
	echo
	echo "Este script crea un archivo .tar.gz como backup de un directorio o archivo"
	echo
	echo "Ejemplo"
	echo " $0 /var/log /backup_dir"
}

if [ "$1" == "-help" ]; then
	mostrar_ayuda
	exit 0
fi


#Argumentos

ORIGEN="$1"
DESTINO="$2"

#Verificar que el origen y el destino existan
if [ ! -e "$ORIGEN" ]; then
	echo "Argumento invalido: $ORIGEN"
	exit 1
fi

if [ ! -e "$DESTINO" ]; then
	echo "Argumento invalido: $DESTINO"
	exit 1
fi

#Fecha en formato ANSI
FECHA=$(date +%Y%m%d)

NOMBRE=$(basename "$ORIGEN")
	
ARCHIVO="${DESTINO}/${NOMBRE}bkp${FECHA}.tar.gz"

tar -czf "$ARCHIVO" "$ORIGEN"

echo "Backup completo: $ARCHIVO"